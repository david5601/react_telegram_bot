export const SET_ACCOUNT_ID = 'SET_ACCOUNT_ID';
export const SET_TH_SPEED = 'SET_TH_SPEED';
export const SET_TRX_RATIO = 'SET_TRX_RATIO';
export const SET_TRX_VALUE = 'SET_TRX_VALUE';
export const SET_BNB_RATIO = 'SET_BNB_RATIO';
export const SET_BNB_VALUE = 'SET_BNB_VALUE';